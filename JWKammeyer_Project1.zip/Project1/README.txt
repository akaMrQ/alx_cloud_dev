Bucket name : 2306816-330469877444-alx-udacity-cdnd-bucket
GIT repo : https://github.com/akaMrQ/alx_cloud_dev
S3 website endpoint : http://2306816-330469877444-alx-udacity-cdnd-bucket.s3-website-us-east-1.amazonaws.com
cloundFont endpoint : d3eac1jylzguor.cloudfront.net